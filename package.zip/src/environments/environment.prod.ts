export const environment = {
  production: true,
  baseurl: 'https://ame-comms-tool-functions.azurewebsites.net',
  apiendpoint: '/api/GetIncident?incident='
};
