export class CustomerInfo{
    CustomerName: string;
    CustomerEmail : string[];
}